package com.example.roomapi.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.roomapi.model.BodyItem
import com.example.roomapi.model.UserModel
import com.example.roomapi.repository.BodyItemRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BodyItemViewModel(private val bodyItemRepository: BodyItemRepository): ViewModel() {

    init {
        viewModelScope.launch (Dispatchers.IO){
            bodyItemRepository.getBodyItem()
        }
    }

    val bodyitem : LiveData<UserModel>
        get() = bodyItemRepository.bodyitem

}