package com.example.roomapi.api

import com.example.roomapi.model.BodyItem
import com.example.roomapi.model.UserModel
import retrofit2.Response
import retrofit2.http.GET

interface ApiInterface {

    @GET("v2/fb-epos-android-activation/devices/short-details/188")
    suspend fun getUserModel() : Response<UserModel>
}