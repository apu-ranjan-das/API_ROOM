package com.example.roomapi.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.example.roomapi.repository.BodyItemRepository

class BodyItemViewModelFactory(private val bodyItemRepository: BodyItemRepository): ViewModelProvider.Factory {

    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return BodyItemViewModel(bodyItemRepository) as T
    }
}