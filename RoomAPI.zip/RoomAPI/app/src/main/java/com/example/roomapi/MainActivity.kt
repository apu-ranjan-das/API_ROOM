package com.example.roomapi

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.ViewModelProvider
import com.example.roomapi.api.ApiInterface
import com.example.roomapi.api.ApiUtilities
import com.example.roomapi.repository.BodyItemRepository
import com.example.roomapi.viewmodel.BodyItemViewModel
import com.example.roomapi.viewmodel.BodyItemViewModelFactory

class MainActivity : AppCompatActivity() {
    private lateinit var bodyItemViewModel: BodyItemViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val repository = (application as MyApplication).bodyitemRepository

        bodyItemViewModel = ViewModelProvider(this, BodyItemViewModelFactory(repository)).get(BodyItemViewModel::class.java)

        bodyItemViewModel.bodyitem.observe(this, {

            Log.d("apidata", "onCreate: ${it.toString()}")

            Toast.makeText(this,"size: ${it.body?.size}",Toast.LENGTH_LONG).show()


//            it.body.iterator().forEach {
//                Log.d("apidata", "bodyitem: ${it.appMode}")
//            }

        })

    }
}