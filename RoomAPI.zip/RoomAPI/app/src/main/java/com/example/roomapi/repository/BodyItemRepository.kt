package com.example.roomapi.repository

import android.content.Context
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.example.roomapi.api.ApiInterface
import com.example.roomapi.model.BodyItem
import com.example.roomapi.model.UserModel
import com.example.roomapi.room.BodyItemDatabase
import com.example.roomapi.util.MyUtils

class BodyItemRepository(
    private val apiInterface: ApiInterface,
    private val bodyItemDatabase: BodyItemDatabase,
    private val applicationContext: Context
) {

    private val bodyitemLiveData = MutableLiveData<UserModel>()

    val bodyitem : LiveData<UserModel>
        get() = bodyitemLiveData

    suspend fun getBodyItem(){
        if (MyUtils.isInternetAvailable(applicationContext)){
            val result = apiInterface.getUserModel()

            if (result.body()!=null){

                bodyItemDatabase.bodyitemDao().insertBodyItem(result.body()!!.body)

                bodyitemLiveData.postValue(result.body())
            }

        }else{
            val bodyitem = bodyItemDatabase.bodyitemDao().getBodyItem()

            val modelList = UserModel(BodyItem(bodyitem),true)
            bodyitemLiveData.postValue(modelList)

        }

    }
}