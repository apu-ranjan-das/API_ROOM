package com.example.roomapi.room

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.roomapi.model.BodyItem

@Database(entities = [BodyItem::class], version = 1)
abstract class BodyItemDatabase : RoomDatabase(){

    abstract fun bodyitemDao() : RoomDao

    companion object{
        private var INSTANCE : BodyItemDatabase? = null

        fun getDatabase(context: Context): BodyItemDatabase{

            if (INSTANCE == null){
                INSTANCE = Room.databaseBuilder(
                    context,
                    BodyItemDatabase::class.java,
                    "bodyitemsDB"
                ).build()
            }

            return INSTANCE!!

        }
    }

}